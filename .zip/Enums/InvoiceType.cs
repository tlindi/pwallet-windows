﻿namespace pWallet.Enums;

public enum InvoiceType
{
	Bolt11Invoice,
	Bolt12Offer,
	LightningAddress,
	OnChainAddress,
	Lnurl,
	Unknown
}