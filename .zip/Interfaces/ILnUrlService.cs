﻿namespace pWallet.Interfaces;

public interface ILnUrlService
{
}
